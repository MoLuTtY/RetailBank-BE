package com.cts.account.model;

public enum AccountType {
    SAVINGS,
    CURRENT
}
