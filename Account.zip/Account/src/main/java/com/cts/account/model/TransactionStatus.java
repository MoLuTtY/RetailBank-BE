package com.cts.account.model;

import lombok.Setter;

@Setter
public class TransactionStatus {
	
	String status;

}
